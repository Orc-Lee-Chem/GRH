# GRH review package — 2026-11-22

This package supplements the repository's `CORRECTION.md` and `CONCLUSIONS.md`. It records
targeted local checks, a review of the supplied Nielsen PDF, selected cache archives, and
reproduction scripts.

**Scope:** the audit concerns the archive's stated RH/GRH target: the Riemann zeta function and
Dirichlet L-functions. It is not a claim about GRH for arbitrary global or automorphic
L-functions.

## Contents

- `CONCLUSIONS.md` — Chinese/English conclusions, scope, and residual limits.
- `files/review-cache/local-verification/` — local controls, receipts, selected cache archives,
  PDF-route extraction, and logs.
- `files/review-cache/local-verification/trust-audit/TRUST_REVIEW_20261122.txt` — detailed review.
- `scripts/` — `DumpEdges.lean`, `InspectOlean.lean`, `bfs_edges.py`, and `README.md`.
- `logs/bfs2.log` — BFS log from a **fresh** SQLite database; first line is
  `source tsv=edges.tsv db=edges_fresh.db`.
- `MANIFEST.sha256` — SHA-256 of every file in this package except the manifest itself.
- `PROVENANCE.json` — original-to-public path/hash mapping for the earlier package files.

## Reproduce the proof-term graph

See `scripts/README.md`. In short:

1. Generate `olean_list.txt` from `.lake/build/lib/lean/**/*.olean`.
2. `lake env lean --run scripts/DumpEdges.lean olean_list.txt edges.tsv`.
3. Set `GRH_EDGES_TSV` and `GRH_EDGES_DB`; run `python scripts/bfs_edges.py > logs/bfs2.log`.

`edges.tsv` and `edges.db` are multi-GB and are not included.

## Limits

- The local checks are targeted; they are not a complete local kernel replay of the RH proof.
- Full proof verification is attributed to the external records cited in `CONCLUSIONS.md`.
- The exact paper-level equivalence of the real `SiegelEisensteinSimplePole` with Tan/Kudla–
  Rallis/Gan–Qiu–Takeda remains a specialist question.
